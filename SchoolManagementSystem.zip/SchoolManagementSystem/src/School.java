import java.util.ArrayList;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc  = new Scanner(System.in);
        HashMap<String,String> Administrators= new HashMap<>();
        Administrators.put("Balaji","1109aA@3");
        Administrators.put("Tharun","1109aA@4");
        Administrators.put("Eeshwar","1109aA@5");
        int totalAmountReceived=0;
        int totalExpenditure=0;
        ArrayList<Integer> TeacherSalaries= new ArrayList<>();
        HashMap<Integer,Student> studentMap= new HashMap<>();
        HashMap<Integer,Teacher> TeacherMap= new HashMap<>();
        while(true){
            System.out.println("Select your Category");
            System.out.println("1: If you are a Student");
            System.out.println("2: If you are a Teacher");
            System.out.println("3: If you want to get details of a student");
            System.out.println("4: If you want to pay fee");
            System.out.println("5: If you want to get details of teacher");
            System.out.println("6: If you are an administrator");
            System.out.println("7: If you want to exit");
            int inp=sc.nextInt();
            if (inp==7){
                break;
            }
            switch(inp){
                case 1:
                    System.out.println("Enter you id: ");
                    int stid=sc.nextInt();
                    System.out.println("Enter your name:");
                    String fake1=sc.nextLine();
                    String stname=sc.nextLine();
                    System.out.println("Enter your current grade:");
                    String currclass=sc.next();
                    Student obj = new Student(stid, stname, currclass);
                    studentMap.put(obj.studentId,obj);
                    System.out.println("You are enrolled. Thank You!!");
                    break;
                case 2:
                    System.out.println("Enter your id: ");
                    int n=sc.nextInt();
                    String fake=sc.nextLine();
                    System.out.println("Enter your name: ");
                    String name=sc.nextLine();
                    System.out.println("Enter your salary");
                    int salary=sc.nextInt();
                    TeacherSalaries.add(salary);
                    Teacher t1=new Teacher(n,name,salary);
                    TeacherMap.put(t1.teacherId,t1);
                    System.out.println("You are enrolled. Thank You!!");
                    break;
                case 3:
                    System.out.println("Enter the Id of the student you are searching");
                    int num=sc.nextInt();
                    if (studentMap.containsKey(num)){
                        Student get= studentMap.get(num);
                        get.getStudentDetails();
                    }else{
                        System.out.println("Your credentials are wrong");
                    }
                    break;
                case 4:
                    System.out.println("Enter your Id");
                    int num1=sc.nextInt();
                    if (studentMap.containsKey(num1)){
                        Student get= studentMap.get(num1);
                        System.out.println("Select your category");
                        System.out.println("1: To check due amount");
                        System.out.println("2: To pay fee");
                        System.out.println("3: To check due amount and pay");
                        int k=sc.nextInt();
                        switch(k){
                            case 1:
                                get.getDueFee();
                                break;
                            case 2:
                                System.out.println("Enter the amount of fee u want to pay");
                                int amount1=sc.nextInt();
                                totalAmountReceived+=amount1;
                                get.updateFee(amount1);
                                System.out.println("you have paid: "+amount1);
                                System.out.print("after paid your due amount is: ");
                                System.out.println(get.getDueFee());

                                break;
                            case 3:
                                get.getDueFee();
                                System.out.println("Enter the amount of fee u want to pay");
                                int amount2=sc.nextInt();
                                get.updateFee(amount2);
                                System.out.println("You have paid :"+amount2);
                                System.out.print("after paid your due amount is: ");
                                get.getDueFee();
                                break;


                        }

                    }else{
                        System.out.println("Your credentials are wrong");
                    }
                    break;
                case 5:System.out.println("Enter the Id of the Teacher you are searching");
                    int num2=sc.nextInt();
                    if (TeacherMap.containsKey(num2)){
                        Teacher get= TeacherMap.get(num2);
                        get.getdetails();
                    }else{
                        System.out.println("Your credentials are wrong");
                    }
                    break;
                case 6:
                    System.out.println("Enter your username: ");
                    String fake12=sc.nextLine();
                    String userName=sc.nextLine();
                    if (Administrators.containsKey(userName)){
                        System.out.println("Enter your password");
                        String userin=sc.nextLine();
                        if (userin.equals(Administrators.get(userName))){
                            while(true){
                                System.out.println("1 : Update your password");
                                System.out.println("2: Exit");
                                System.out.println("3: check Spent Funds");
                                System.out.println("4: check received Funds");
                                System.out.println("5: to check profit");
                                int inputA=sc.nextInt();
                                if (inputA==2){
                                    break;
                                }
                                switch(inputA){
                                    case 1:
                                        System.out.println("Enter your password: ");
                                        Administrators.put(userName,sc.next());
                                        break;
                                    case 3:
                                        int sum=0;
                                        for(int i: TeacherSalaries){
                                            sum+=i;
                                        }
                                        System.out.println("Spent funds in form of salaries: "+sum);
                                        break;
                                    case 4:
                                        System.out.println("Received funds in form of fee are: "+totalAmountReceived);
                                        break;
                                    case 5:
                                        int sum1=0;
                                        for(int i: TeacherSalaries){
                                            sum1+=i;
                                        }
                                        System.out.println("Spent funds in form of salaries: "+(totalAmountReceived-sum1));
                                        break;
                                }
                            }

                        }
                        else{
                            System.out.println("Incorrect Password");
                        }
                    }else{
                        System.out.println("Incorrect Username");
                    }


            }



        }
    }
}