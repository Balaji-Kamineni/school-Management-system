public class Student {
 int studentId;
 String studentName;
 String studentClass;
    static int totalFee;
int totalFeePaid;
    Student(int studentId,String studentName,String studentClass){
        this.studentId=studentId;
        this.studentName=studentName;
        this.studentClass=studentClass;
        totalFee=30000;
        totalFeePaid=0;
    }
    public void getStudentDetails(){
        System.out.println("Student Id is : "+studentId);
        System.out.println("Student Name is : "+studentName);
        System.out.println("Student is in "+studentClass+" grade");
        System.out.println("student having due "+ (totalFee-totalFeePaid));
    }
    public void updateFee(int amount) {
        this.totalFeePaid += amount;
    }
    public void updateClass(String newGrade){
        this.studentClass=newGrade;
    }
    public int getDueFee(){
        return totalFee-totalFeePaid;
    }
}
