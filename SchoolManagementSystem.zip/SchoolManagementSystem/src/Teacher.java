import java.util.*;

public class Teacher {
    public int teacherId;
    public String teacherName;
    int salary;
    ArrayList<String> subjects=new ArrayList<>();
    Scanner sc = new Scanner(System.in);
    Teacher(int teacherId,String teacherName,int salary){
        this.teacherId=teacherId;
        this.teacherName=teacherName;
        this.salary=salary;
        System.out.println("Enter how many subjects you teach? ");
        int n=sc.nextInt();
        ArrayList<String> fake=new ArrayList<>();
        for(int i=0;i<n;i++){
            fake.add(sc.next());
        }
        this.subjects=fake;
    }
    void getdetails(){
        System.out.println("Teachcer id is : "+this.teacherId);
        System.out.println("Teacher name is : "+this.teacherName);
        System.out.println("Teacher Salary is : "+this.salary);
        System.out.print("Subjects taught by "+this.teacherName+" are : ");
        if (subjects.size()==0){
            System.out.println("No subjects");
        }else{
            for (String i : subjects) {
                System.out.print(i + " ");
            }
            System.out.println();
        }
    }

}
